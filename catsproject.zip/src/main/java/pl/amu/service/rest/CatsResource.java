package pl.amu.service.rest;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.security.core.userdetails.UserDetails;
import pl.amu.service.rest.model.Cat;
import pl.amu.service.rest.model.ErrorMessage;
import pl.amu.service.rest.exception.UsersAppExceptions;

import javax.validation.Valid;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;

/**
 * Created by win10 on 14.05.2017.
 */
@Api
@Path("/cats")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class CatsResource {
    @Autowired
    private CatsService catsService;
    private UsersService usersService;
    private static Logger logger = LoggerFactory.getLogger(CatsResource.class);

    @GET
    public Response getAllCats() {
        logger.info("GET /cats");
        return Response.ok(catsService.getCats())
                .build();
    }

    @POST
    @ApiOperation("Adds a cat")
    public Response createCat(@Valid Cat cat) throws UsersAppExceptions {
        if (catsService.findById(cat.getId().toLowerCase()) == null) {
            logger.info("POST /cats");
            return Response
                    .ok(catsService.save(cat))
                    .build();
        }

        throw new UsersAppExceptions("Kot " + cat.getId() + " już jest w bazie", "USER_ALREADY_REGISTERED", Response.Status.CONFLICT);
    }

    @ApiOperation("Updates a cat")
    @PUT()
    @Path("/{id}")
    public Response updateCat(@PathParam("id") String Id, Cat cat) throws UsersAppExceptions {
        logger.info("PUT /cats/" + Id);
        if (catsService.findById(Id) == null) {
            throw new UsersAppExceptions("Kot o id " + Id + " nie znaleziony", "USER_NOT_FOUND", Response.Status.CONFLICT);
        }
        cat.setId(Id);
        return Response.ok(catsService.save(cat)).build();
    }

    @ApiOperation("Return cat with given id")
    @ApiResponses({
            @ApiResponse(code = 404, message = "Returned when cat with given id doesn't exist", response = ErrorMessage.class)
    })
    @GET
    @Path("/{id}")
    public Response getCat(@PathParam("id") final String Id, @Context Request request) throws UsersAppExceptions {
        logger.info("GET /cats/" + Id);

        if (catsService.findById(Id) == null) {
            throw new UsersAppExceptions("Użytkownik " + Id + " nie znaleziony", "USER_NOT_FOUND", Response.Status.NOT_FOUND);
        }


        return Response.ok(catsService.findById(Id))
                .build();
    }

    @ApiOperation("Removes user from database")
    @DELETE
    @Path("/{id}")
    public String deleteCat(@PathParam("id") final String Id) throws UsersAppExceptions {
        logger.info("DELETE /cats/" + Id);
        Cat cat = catsService.remove(Id);

        if (cat == null) {
            throw new UsersAppExceptions("Kot o id " + Id + " nie znaleziony", "USER_NOT_FOUND", Response.Status.NOT_FOUND);
        }
        for(String hooman:cat.hoomans){
            usersService.findByLogin(hooman).observedcats.remove(Id);
        }
        return "Kot "+Id+" został usunięty ze strony.";
    }
}
