package pl.amu.service.rest;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import pl.amu.service.rest.model.Cat;
import pl.amu.service.rest.model.User;
import pl.amu.service.rest.exception.UsersAppExceptions;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * Created by win10 on 21.05.2017.
 */
@Api
@Path("/users/{login}/observedcats")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class ObservingResource {
    @Autowired
    private CatsService catsservice;
    @Autowired
    private UsersService usersservice;
    @GET
    @ApiOperation("Shows all cats observed by user.")
    public Response getmycats(@PathParam("login") final String login) throws UsersAppExceptions {
        User user=usersservice.findByLogin(login.toLowerCase());
        if (user == null) {
            throw new UsersAppExceptions("Użytkownik " + login + " nie znaleziony", "USER_NOT_FOUND", Response.Status.NOT_FOUND);
        }
        return Response.ok(user.getObservedcats())
                .build();
    }
    @POST
    @ApiOperation("Starts observing a cat.")
    public Cat addcat(@PathParam("login") final String login,String Id) throws UsersAppExceptions{
        Id=Id.toLowerCase();
        User user=usersservice.findByLogin(login.toLowerCase());
        if (user == null) {
            throw new UsersAppExceptions("Użytkownik " + login + " nie znaleziony", "USER_NOT_FOUND", Response.Status.NOT_FOUND);
        }
        Cat cat=catsservice.findById(Id);
        if(cat==null){
            throw new UsersAppExceptions("Kot o id " + Id + " nie znaleziony", "CAT_NOT_FOUND", Response.Status.NOT_FOUND);
        }
        user.observedcats.add(Id);
        cat.hoomans.add(login.toLowerCase());
        return cat;
    }
    @Path("/{Id}")
    @DELETE
    @ApiOperation("Starts observing a cat.")
    public Response removecat(@PathParam("login") String login, @PathParam("Id") String Id) throws UsersAppExceptions{
        login=login.toLowerCase();
        User user=usersservice.findByLogin(login.toLowerCase());
        if (user == null) {
            throw new UsersAppExceptions("Użytkownik " + login + " nie znaleziony", "USER_NOT_FOUND", Response.Status.NOT_FOUND);
        }
        if(!user.observedcats.remove(Id.toLowerCase())){
            throw new UsersAppExceptions("Kot o id " + Id + " nie znaleziony", "CAT_NOT_FOUND", Response.Status.NOT_FOUND);
        }
        Cat cat=catsservice.findById(Id.toLowerCase());
        cat.hoomans.remove(login);

        return Response.ok(Id).build();
    }
}
